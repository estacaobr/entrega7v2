import { Component, OnInit } from '@angular/core';
import { Usuario } from '../model/user.model';
import { AutenticacaoService } from './../services/autenticacao.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  public srcLogoImage = "./../../assets/img/prateleira.png";
  public srcLogoImage1 = "./../../assets/img/design.png";
  public usuario: Usuario = new Usuario();


  public form: FormGroup;

  constructor(private formBuilder: FormBuilder, private auth: AutenticacaoService) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      email: ['', Validators.compose([Validators.required,
                                      Validators.email,
                                      Validators.minLength(8),
                                      Validators.minLength(40)])],

      senha:  ['', Validators.compose([Validators.required,
                                       Validators.minLength(6)])],
    })

  }

  public realizarLogin(){
    this.auth.logar(this.usuario);
  }
}
